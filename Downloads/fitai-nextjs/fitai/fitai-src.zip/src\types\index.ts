// src/types/index.ts

export type Goal = 'weight_loss' | 'muscle_gain' | 'maintain' | 'healthy_life'
export type Gender = 'male' | 'female'
export type BodyType = 'ectomorph' | 'mesomorph' | 'endomorph' | 'unknown'
export type PlanType = 'free' | 'pro_monthly' | 'pro_yearly'

export interface UserProfile {
  id: string
  height: number       // sm
  weight: number       // kg
  age: number
  gender: Gender
  goal: Goal
  body_type?: BodyType
  bmi?: number
  fat_percentage?: number
  plan_type: PlanType
  created_at: string
}

export interface AnalysisResult {
  id: string
  bmi: number
  fat_percentage: number
  body_type: BodyType
  ai_summary: string
  weight_loss_estimate: number
  recommendations: string[]
  body_score?: number
  confidence?: number
  image_quality?: 'low' | 'medium' | 'high'
  created_at: string
}
export interface Meal {
  name: string          // "Nonushta"
  time: string          // "08:00"
  foods: FoodItem[]
  total_calories: number
  recipe?: Recipe
}

export interface FoodItem {
  name: string          // "Tuxum"
  amount: string        // "2 dona"
  calories: number
  protein: number       // g
  carbs: number         // g
  fat: number           // g
}

export interface Recipe {
  ingredients: string[]
  steps: string[]
  cook_time: number     // daqiqa
}

export interface DietDay {
  day: number
  meals: Meal[]
  total_calories: number
  water_intake: number  // litr
}

export interface Exercise {
  name: string
  sets?: number
  reps?: string         // "12-15" yoki "30 soniya"
  duration?: number     // daqiqa
  rest: number          // soniya
  description: string
  muscle_group: string
  video_url?: string
}

export interface WorkoutDay {
  day: number
  title: string         // "Yuqori tana"
  exercises: Exercise[]
  duration: number      // daqiqa
  calories_burned: number
}

export interface WeightProgress {
  week: number
  estimated_weight: number
  actual_weight?: number
}

export interface OnboardingData {
  height: string
  weight: string
  age: string
  gender: Gender | ''
  goal: Goal | ''
  image: File | null
}
