'use client'
// src/app/dashboard/progress/page.tsx

import { useUserStore } from '@/store/userStore'
import Link from 'next/link'
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, ReferenceLine
} from 'recharts'

interface CustomTooltipProps {
  active?: boolean;
  payload?: any[];
  label?: string;
}

const CustomTooltip = ({ active, payload, label }: CustomTooltipProps) => {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-[#1a1a1a] border border-white/10 rounded-xl px-3 py-2 text-sm">
      <p className="text-gray-400 text-xs mb-1">{label}</p>
      {payload.map((p) => (
        p.value !== null && (
          <p key={p.name} style={{ color: p.color }} className="font-medium">
            {p.name === 'taxmin' ? 'Taxmin' : 'Haqiqiy'}: {p.value} kg
          </p>
        )
      ))}
    </div>
  )
}

export default function ProgressPage() {
  const { analysis, onboardingData } = useUserStore()

  const startWeight = Number(onboardingData.weight) || 75
  const lossPerMonth = analysis?.weight_loss_estimate || 4
  const lossPerWeek = lossPerMonth / 4.3

  // 12 haftalik taxminiy grafik
  const chartData = Array.from({ length: 13 }, (_, i) => ({
    week: i === 0 ? 'Boshlang\'ich' : `${i}-hafta`,
    taxmin: parseFloat((startWeight - lossPerWeek * i).toFixed(1)),
    haqiqiy: i === 0 ? startWeight : null,
  }))

  const targetWeight = parseFloat((startWeight - lossPerMonth * 3).toFixed(1))

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white">
      {/* Header */}
      <div className="border-b border-white/8 px-4 py-4 flex items-center gap-3">
        <Link href="/dashboard" className="text-gray-400 hover:text-white transition-colors text-lg">←</Link>
        <div>
          <h1 className="font-bold text-lg" style={{ fontFamily: 'var(--font-clash)' }}>Progress</h1>
          <p className="text-xs text-gray-500">Vazn yo&apos;qotish grafigi</p>
        </div>
      </div>

      <div className="max-w-lg mx-auto px-4 py-6">

        {/* Stat kartalar */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
          <div className="bg-[#111] border border-white/8 rounded-2xl p-4 text-center">
            <div className="text-2xl font-bold text-white mb-1" style={{ fontFamily: 'var(--font-clash)' }}>
              {startWeight}
            </div>
            <div className="text-xs text-gray-500 uppercase tracking-wider">Boshlang&apos;ich kg</div>
          </div>
          <div className="bg-[#111] border border-[#c8f55a]/20 rounded-2xl p-4 text-center">
            <div className="text-2xl font-bold text-[#c8f55a] mb-1" style={{ fontFamily: 'var(--font-clash)' }}>
              ~{lossPerMonth}
            </div>
            <div className="text-xs text-gray-500 uppercase tracking-wider">Oyda kg taxmin</div>
          </div>
          <div className="bg-[#111] border border-white/8 rounded-2xl p-4 text-center">
            <div className="text-2xl font-bold text-[#ff6b35] mb-1" style={{ fontFamily: 'var(--font-clash)' }}>
              {targetWeight}
            </div>
            <div className="text-xs text-gray-500 uppercase tracking-wider">3 oyda maqsad</div>
          </div>
        </div>

        {/* Grafik */}
        <div className="bg-[#111] border border-white/8 rounded-2xl p-5 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold" style={{ fontFamily: 'var(--font-clash)' }}>
              12 haftalik taxmin
            </h2>
            <div className="flex gap-3 text-xs">
              <span className="flex items-center gap-1.5 text-gray-500">
                <span className="w-3 h-0.5 bg-[#c8f55a] inline-block rounded" />
                Taxmin
              </span>
            </div>
          </div>

          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={chartData} margin={{ top: 5, right: 5, left: -20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis
                dataKey="week"
                tick={{ fill: '#444', fontSize: 10 }}
                interval={2}
                tickLine={false}
                axisLine={false}
              />
              <YAxis
                tick={{ fill: '#444', fontSize: 10 }}
                tickLine={false}
                axisLine={false}
                domain={['auto', 'auto']}
              />
              <Tooltip content={<CustomTooltip />} />
              <ReferenceLine
                y={targetWeight}
                stroke="#ff6b35"
                strokeDasharray="4 4"
                strokeWidth={1}
              />
              <Line
                type="monotone"
                dataKey="taxmin"
                stroke="#c8f55a"
                strokeWidth={2}
                dot={{ fill: '#c8f55a', r: 3, strokeWidth: 0 }}
                activeDot={{ r: 5, fill: '#c8f55a' }}
              />
            </LineChart>
          </ResponsiveContainer>

          <p className="text-xs text-gray-600 text-center mt-2">
            Qizil chiziq — 3 oylik maqsad ({targetWeight} kg)
          </p>
        </div>

        {/* Haftalik taxmin jadval */}
        <div className="bg-[#111] border border-white/8 rounded-2xl overflow-hidden mb-6">
          <div className="px-5 py-4 border-b border-white/8">
            <h2 className="font-semibold" style={{ fontFamily: 'var(--font-clash)' }}>
              Haftalik taxmin
            </h2>
          </div>
          <div className="divide-y divide-white/5">
            {chartData.slice(1, 9).map((d, i) => (
              <div key={i} className="flex items-center justify-between px-5 py-3">
                <span className="text-sm text-gray-400">{d.week}</span>
                <div className="flex items-center gap-3">
                  <span className="text-xs text-[#c8f55a]">
                    -{parseFloat((lossPerWeek * (i + 1)).toFixed(1))} kg
                  </span>
                  <span className="text-sm font-medium text-white">{d.taxmin} kg</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Pro — haqiqiy progress */}
        <div className="bg-[#c8f55a]/8 border border-[#c8f55a]/20 rounded-2xl p-5 text-center">
          <div className="text-lg mb-1">📸</div>
          <h3 className="font-bold mb-1" style={{ fontFamily: 'var(--font-clash)' }}>
            Haqiqiy progress kuzatuv
          </h3>
          <p className="text-gray-400 text-xs mb-3">
            Haftalik rasm yuklash, AI taqqoslash, aniq o&apos;zgarish
          </p>
          <button className="bg-[#c8f55a] text-black text-sm font-semibold px-6 py-2.5 rounded-full hover:opacity-90 transition-opacity">
            Pro — $4.99/oy
          </button>
        </div>
      </div>
    </div>
  )
}
