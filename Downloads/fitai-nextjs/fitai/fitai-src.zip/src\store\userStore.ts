// src/store/userStore.ts
import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { UserProfile, AnalysisResult, DietDay, WorkoutDay, OnboardingData } from '@/types'

interface UserStore {
  // Onboarding
  onboardingData: OnboardingData
  setOnboardingData: (data: Partial<OnboardingData>) => void
  resetOnboarding: () => void

  // Profile
  profile: UserProfile | null
  setProfile: (profile: UserProfile | null) => void

  // Analysis
  analysis: AnalysisResult | null
  setAnalysis: (analysis: AnalysisResult | null) => void

  // Plans
  dietPlan: DietDay[]
  workoutPlan: WorkoutDay[]
  setDietPlan: (plan: DietDay[]) => void
  setWorkoutPlan: (plan: WorkoutDay[]) => void

  // UI
  isLoading: boolean
  setLoading: (loading: boolean) => void
}

const defaultOnboarding: OnboardingData = {
  height: '',
  weight: '',
  age: '',
  gender: '',
  goal: '',
  image: null,
}

export const useUserStore = create<UserStore>()(
  persist(
    (set) => ({
      onboardingData: defaultOnboarding,
      setOnboardingData: (data) =>
        set((s) => ({ onboardingData: { ...s.onboardingData, ...data } })),
      resetOnboarding: () => set({ onboardingData: defaultOnboarding }),

      profile: null,
      setProfile: (profile) => set({ profile }),

      analysis: null,
      setAnalysis: (analysis) => set({ analysis }),

      dietPlan: [],
      workoutPlan: [],
      setDietPlan: (dietPlan) => set({ dietPlan }),
      setWorkoutPlan: (workoutPlan) => set({ workoutPlan }),

      isLoading: false,
      setLoading: (isLoading) => set({ isLoading }),
    }),
    {
      name: 'fitai-store',
      partialize: (s) => ({
        profile: s.profile,
        analysis: s.analysis,
        dietPlan: s.dietPlan,
        workoutPlan: s.workoutPlan,
      }),
    }
  )
)
