import { createServerClient } from '@supabase/ssr'
import { NextResponse, type NextRequest } from 'next/server'

export async function GET(request: NextRequest) {
  const { searchParams, origin } = new URL(request.url)
  const code = searchParams.get('code')
  const errorMsg = searchParams.get('error')

  // ❗ Agar darhol xato bo‘lsa
  if (errorMsg) {
    return NextResponse.redirect(`${origin}/auth?error=${encodeURIComponent(errorMsg)}`)
  }

  if (code) {
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
    const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

    if (!supabaseUrl || !supabaseKey || supabaseUrl.startsWith('your_')) {
      return NextResponse.redirect(`${origin}/auth?error=missing_keys`)
    }

    const response = NextResponse.redirect(`${origin}/onboarding`)

    const supabase = createServerClient(supabaseUrl, supabaseKey, {
      cookies: {
        getAll: () => request.cookies.getAll(),
        setAll: (list) => {
          list.forEach(({ name, value, options }) =>
            response.cookies.set(name, value, options)
          )
        },
      },
    })

    const { error } = await supabase.auth.exchangeCodeForSession(code)

    if (error) {
      console.error('Callback error:', error)
      return NextResponse.redirect(`${origin}/auth?error=exchange_failed`)
    }

    // Yangi user uchun onboarding ga redirect
    return NextResponse.redirect(`${origin}/onboarding`)
  }

  return NextResponse.redirect(`${origin}/auth?error=no_code`)
}